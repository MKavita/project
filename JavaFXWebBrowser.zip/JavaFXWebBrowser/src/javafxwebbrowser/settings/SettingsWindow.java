package javafxwebbrowser.settings;

//TODO
public class SettingsWindow {
	
}
