/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxwebbrowser.qualityParameters;

// import packages
import java.io.BufferedInputStream;
import java.net.URL;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javafxwebbrowser.browser.WebBrowserTabController;
/*
import static com.sun.javafx.css.FontFace.FontFaceSrcType.URL;
import java.io.IOException;
import java.net.MalformedURLException;
import javafx.fxml.FXML;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.scene.control.TextField;
import static javafx.scene.input.DataFormat.URL;
import javafxwebbrowser.tools.InfoTool;
import javafxwebbrowser.settings.SettingsWindow;
import javafxwebbrowser.marquee.FXMarquee;
import javafxwebbrowser.browser.WebBrowserController;
import javafxwebbrowser.browser.WebBrowserTabContextMenu;
import javafxwebbrowser.application.Main;
import static sun.management.Agent.error;
*/

/**
 *
 * @author KAVI
 */
public class bandwidthQOS {

    long totalDownload = 0; // total bytes downloaded
    final int BUFFER_SIZE = 1024; // size of the buffer
    byte[] data = new byte[BUFFER_SIZE]; // buffer
    
    public bandwidthQOS(){
   //System.out.println("Final URL => FURL => " + fURL);TabController.returnsFinalUr
    //javafxwebbrowser.browser.WebBrowserTabController s = new javafxwebbrowser.browser.WebBrowserTabController();
   
     fURL = javafxwebbrowser.browser.WebBrowserTabController.returnsFinalUrl();
        System.out.println("Final URL => FURL => " + fURL);
    }
    
    public static String fURL="";
        
    /*
    public void test(){
       // fURL = s.returnsFinalUrl();
    }
    */
    
    public void calc(){    
        try{
            System.out.println("Inside the calc function: ");
                                
            BufferedInputStream in = new BufferedInputStream(new URL(fURL).openStream());
            
            System.out.println("After Bufferd line");
            
            int dataRead = 0; // data read in each try
            Date d=new Date();
            double startTime=(double)(d.getTime()/1000);
           // double startTime = (double)(System.currentTimeMillis()/1000);// starting time of download
            System.out.println("start Time: "+ startTime);
            
//            System.out.println("statrt time inititated");
                
            long tdConvert=0;
            
            while ((dataRead = in.read(data, 0, 1024)) > 0) {
                
                System.out.println("Insode while loop");
                totalDownload += dataRead; // adding data downloaded to total data

                System.out.println("total Download: "+ totalDownload);  
                
                // Converting totalDownload into nanoTime
                
               // System.out.println("total Download Converted: "+ tdConvert + " nanoSecods");                         
              
            }
                System.out.println("Outsid while loop");
    
            /* download rate in bytes per second */
            
           /// System.out.println("System Per Sec time : "+);
           double ct=d.getTime()/1000;
           double t=(double)(ct - startTime);
            System.out.println(t +" time difference");
            
            
            //System.out.println((System.nanoTime() - startTime)/1000000000 +" denominator part");
            
            System.out.println("AAAAAAAAAA");
            
            double bytesPerSec = totalDownload/ t;
            System.out.println(bytesPerSec);    
    
    //        long bytesPerSec = tdConvert/ ((System.nanoTime() - startTime) / 1000000000);
 //           float bytesPerSec = tdConvert/ ((System.nanoTime() - startTime) / 1000000000);
            
            System.out.println(bytesPerSec + " Bps");
    

    
            System.out.println("start Time: "+ startTime);
            
            /* download rate in kilobytes per second */
            double kbPerSec = bytesPerSec / (1024);
            System.out.println(kbPerSec + " KBps ");
    
            /* download rate in megabytes per second */
            double mbPerSec = kbPerSec / (1024);
            System.out.println(mbPerSec + " MBps ");  
        }
        
        catch(Exception ex){
            System.out.println(ex);
        }
    }

}
