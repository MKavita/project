package main.java.com.goxr3plus.javafxwebbrowser.settings;

//TODO
public class SettingsWindow {
	
}
